
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { RefreshCw, Send, Sparkles, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import { aiService } from '@/services/ai';
import { twitterService } from '@/services/twitter';

interface PostCreatorProps {
  onPostCreated?: () => void;
}

const PostCreator: React.FC<PostCreatorProps> = ({ onPostCreated }) => {
  const [postContent, setPostContent] = useState('');
  const [tone, setTone] = useState<'professional' | 'casual' | 'enthusiastic'>('professional');
  const [length, setLength] = useState<'short' | 'medium' | 'long'>('medium');
  const [includeHashtags, setIncludeHashtags] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPosting, setIsPosting] = useState(false);
  const [isScheduling, setIsScheduling] = useState(false);

  const handleGenerateClick = async () => {
    setIsGenerating(true);
    
    try {
      const generatedPost = await aiService.generateTweet({
        tone,
        length,
        includeHashtags
      });
      
      setPostContent(generatedPost);
      toast.success('Generated new post content');
    } catch (error) {
      console.error('Failed to generate post:', error);
      toast.error('Failed to generate post content');
    } finally {
      setIsGenerating(false);
    }
  };
  
  const handlePostNow = async () => {
    if (!postContent.trim()) {
      toast.error('Please generate or enter post content first');
      return;
    }
    
    setIsPosting(true);
    
    try {
      if (!twitterService.isConnected()) {
        toast.error('Please connect to Twitter first');
        return;
      }
      
      await twitterService.postTweet(postContent);
      toast.success('Posted successfully to Twitter!');
      setPostContent('');
      
      if (onPostCreated) {
        onPostCreated();
      }
    } catch (error) {
      console.error('Failed to post:', error);
      toast.error('Failed to post to Twitter: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setIsPosting(false);
    }
  };
  
  const handleSchedulePost = () => {
    if (!postContent.trim()) {
      toast.error('Please generate or enter post content first');
      return;
    }
    
    // In a real app, you would show a scheduling dialog here
    setIsScheduling(true);
    
    // Simulate scheduling
    setTimeout(() => {
      toast.success('Post scheduled for later');
      setPostContent('');
      setIsScheduling(false);
      
      if (onPostCreated) {
        onPostCreated();
      }
    }, 1500);
  };

  return (
    <Card className="shadow-soft overflow-hidden border border-white/10 bg-gradient-glass backdrop-blur-sm">
      <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10 pb-4">
        <CardTitle className="text-lg font-medium flex items-center gap-2">
          <Sparkles size={18} className="text-primary" />
          Create AI-Powered Post
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tone">Content Tone</Label>
              <Select value={tone} onValueChange={(value: any) => setTone(value)}>
                <SelectTrigger id="tone" className="bg-white/5 border-white/10">
                  <SelectValue placeholder="Select tone" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="casual">Casual</SelectItem>
                  <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="length">Content Length</Label>
              <Select value={length} onValueChange={(value: any) => setLength(value)}>
                <SelectTrigger id="length" className="bg-white/5 border-white/10">
                  <SelectValue placeholder="Select length" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="short">Short</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="long">Long</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch
              id="hashtags"
              checked={includeHashtags}
              onCheckedChange={setIncludeHashtags}
            />
            <Label htmlFor="hashtags">Include relevant hashtags</Label>
          </div>
          
          <Separator />
          
          <div className="space-y-2">
            <Label htmlFor="content">Post Content</Label>
            <Textarea
              id="content"
              placeholder="Generate AI content or write your own..."
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              className="min-h-[120px] bg-white/5 backdrop-blur-sm border-white/10 resize-none"
            />
          </div>
          
          <Button
            variant="outline"
            size="sm"
            className="w-full border-primary/20 text-primary hover:bg-primary/10"
            onClick={handleGenerateClick}
            disabled={isGenerating}
          >
            <RefreshCw size={16} className={`mr-2 ${isGenerating ? 'animate-spin' : ''}`} />
            {isGenerating ? 'Generating...' : 'Generate with AI'}
          </Button>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between gap-4 bg-gradient-to-r from-primary/5 to-primary/10 border-t border-white/10">
        <Button
          variant="outline"
          onClick={handleSchedulePost}
          disabled={isScheduling || !postContent.trim()}
          className="w-1/2 border-white/20 backdrop-blur-sm hover:bg-white/10"
        >
          <Calendar size={16} className="mr-2" />
          {isScheduling ? 'Scheduling...' : 'Schedule'}
        </Button>
        <Button
          onClick={handlePostNow}
          disabled={isPosting || !postContent.trim()}
          className="w-1/2 bg-twitter-blue hover:bg-twitter-dark text-white"
        >
          <Send size={16} className="mr-2" />
          {isPosting ? 'Posting...' : 'Post Now'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default PostCreator;
