
import React from 'react';
import { cn } from '@/lib/utils';

interface ContainerProps {
  children: React.ReactNode;
  className?: string;
  fullWidth?: boolean;
}

const Container: React.FC<ContainerProps> = ({
  children,
  className,
  fullWidth = false,
}) => {
  return (
    <div
      className={cn(
        'w-full px-4 sm:px-6 md:px-8 mx-auto animate-fade-in',
        {
          'max-w-7xl': !fullWidth,
        },
        className
      )}
    >
      {children}
    </div>
  );
};

export default Container;
