
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Zap, Hash, Users, MessageSquare, Repeat, Heart } from 'lucide-react';
import { toast } from 'sonner';

const EngagementSettings: React.FC = () => {
  const [autoLike, setAutoLike] = useState(true);
  const [autoRetweet, setAutoRetweet] = useState(false);
  const [autoReply, setAutoReply] = useState(false);
  const [engagementFrequency, setEngagementFrequency] = useState([4]); // 4 times per day
  const [saveInProgress, setSaveInProgress] = useState(false);
  
  const [keywords, setKeywords] = useState(['ai', 'machine learning', 'tech']);
  const [newKeyword, setNewKeyword] = useState('');

  const handleAddKeyword = () => {
    if (newKeyword.trim() && !keywords.includes(newKeyword.trim().toLowerCase())) {
      setKeywords([...keywords, newKeyword.trim().toLowerCase()]);
      setNewKeyword('');
    }
  };

  const handleRemoveKeyword = (index: number) => {
    setKeywords(keywords.filter((_, i) => i !== index));
  };

  const handleSaveSettings = () => {
    setSaveInProgress(true);
    
    // Simulate API call
    setTimeout(() => {
      toast.success('Engagement settings saved successfully');
      setSaveInProgress(false);
    }, 1000);
  };

  return (
    <Card className="shadow-soft border border-white/10 bg-gradient-glass backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-full bg-primary/10 text-primary">
            <Zap size={18} />
          </div>
          <div>
            <CardTitle className="text-lg font-medium">Engagement Settings</CardTitle>
            <CardDescription>Configure how your AI agent interacts with other accounts</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="flex flex-col space-y-1.5">
            <h3 className="font-medium flex items-center gap-2">
              <Hash size={16} className="text-muted-foreground" />
              Target Keywords
            </h3>
            <p className="text-sm text-muted-foreground">
              Your agent will engage with posts containing these keywords
            </p>
          </div>
          
          <div className="flex flex-wrap gap-2 mt-2">
            {keywords.map((keyword, index) => (
              <div 
                key={index} 
                className="group flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm"
              >
                {keyword}
                <button 
                  onClick={() => handleRemoveKeyword(index)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity ml-1"
                >
                  &times;
                </button>
              </div>
            ))}
          </div>
          
          <div className="flex gap-2">
            <Input
              value={newKeyword}
              onChange={(e) => setNewKeyword(e.target.value)}
              placeholder="Add a keyword"
              className="bg-white/5 border-white/10"
              onKeyDown={(e) => e.key === 'Enter' && handleAddKeyword()}
            />
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleAddKeyword}
              className="border-primary/20 text-primary hover:bg-primary/10"
            >
              Add
            </Button>
          </div>
        </div>
        
        <Separator />
        
        <div className="space-y-4">
          <div className="flex flex-col space-y-1.5">
            <h3 className="font-medium flex items-center gap-2">
              <Users size={16} className="text-muted-foreground" />
              Auto-Engagement
            </h3>
            <p className="text-sm text-muted-foreground">
              Configure what types of engagement your agent will perform
            </p>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Heart size={16} className="text-destructive/70" />
                <Label htmlFor="auto-like">Auto-Like Relevant Posts</Label>
              </div>
              <Switch 
                id="auto-like" 
                checked={autoLike}
                onCheckedChange={setAutoLike}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Repeat size={16} className="text-green-600/70" />
                <Label htmlFor="auto-retweet">Auto-Retweet Top Content</Label>
              </div>
              <Switch 
                id="auto-retweet" 
                checked={autoRetweet}
                onCheckedChange={setAutoRetweet}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <MessageSquare size={16} className="text-twitter-blue/70" />
                <Label htmlFor="auto-reply">AI-Generated Replies</Label>
              </div>
              <Switch 
                id="auto-reply" 
                checked={autoReply}
                onCheckedChange={setAutoReply}
              />
            </div>
          </div>
        </div>
        
        <Separator />
        
        <div className="space-y-4">
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="frequency-slider">Engagement Frequency</Label>
            <p className="text-sm text-muted-foreground">
              {engagementFrequency[0] === 1 
                ? 'Once per day' 
                : `${engagementFrequency[0]} times per day`}
            </p>
          </div>
          
          <Slider
            id="frequency-slider"
            defaultValue={[4]}
            max={10}
            step={1}
            min={1}
            value={engagementFrequency}
            onValueChange={setEngagementFrequency}
            className="py-4"
          />
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={handleSaveSettings} 
          disabled={saveInProgress}
          className="w-full bg-primary"
        >
          {saveInProgress ? 'Saving...' : 'Save Settings'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default EngagementSettings;
