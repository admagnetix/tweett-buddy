
import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

const QuickLinks: React.FC = () => {
  return (
    <Card className="shadow-soft border border-white/10 bg-gradient-glass backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-lg font-medium">Quick Links</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <Button variant="ghost" asChild className="w-full justify-between">
          <Link to="/analytics">
            <span>Analytics Dashboard</span>
            <ChevronRight size={16} />
          </Link>
        </Button>
        <Separator />
        <Button variant="ghost" asChild className="w-full justify-between">
          <Link to="/settings">
            <span>Account Settings</span>
            <ChevronRight size={16} />
          </Link>
        </Button>
        <Separator />
        <Button variant="ghost" asChild className="w-full justify-between">
          <Link to="/help">
            <span>Help & Documentation</span>
            <ChevronRight size={16} />
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
};

export default QuickLinks;
