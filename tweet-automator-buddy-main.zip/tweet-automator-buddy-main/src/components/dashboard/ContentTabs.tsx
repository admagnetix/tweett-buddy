
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PostCreator from '@/components/posts/PostCreator';
import PostHistory from './PostHistory';
import type { Tweet } from '@/services/twitter';

interface ContentTabsProps {
  recentTweets: Tweet[];
  isLoading: boolean;
  onPostCreated: () => Promise<void>;
}

const ContentTabs: React.FC<ContentTabsProps> = ({ 
  recentTweets, 
  isLoading, 
  onPostCreated 
}) => {
  return (
    <Tabs defaultValue="create" className="w-full">
      <TabsList className="grid grid-cols-2 mb-6">
        <TabsTrigger value="create" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Create Content</TabsTrigger>
        <TabsTrigger value="history" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Post History</TabsTrigger>
      </TabsList>
      
      <TabsContent value="create" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
        <PostCreator onPostCreated={onPostCreated} />
      </TabsContent>
      
      <TabsContent value="history" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
        <PostHistory isLoading={isLoading} recentTweets={recentTweets} />
      </TabsContent>
    </Tabs>
  );
};

export default ContentTabs;
