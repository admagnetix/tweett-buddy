
import React from 'react';
import { InfoIcon, MessageSquare, Zap, LineChart } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import type { Tweet } from '@/services/twitter';

interface PostHistoryProps {
  isLoading: boolean;
  recentTweets: Tweet[];
}

const PostHistory: React.FC<PostHistoryProps> = ({ isLoading, recentTweets }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const isSimulatedTweet = (id: string) => id.startsWith('simulated-');

  return (
    <Card className="shadow-soft border border-white/10 bg-gradient-glass backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-lg font-medium">Recent Posts</CardTitle>
        <CardDescription>
          View your simulated and example Twitter posts
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="py-8 text-center text-muted-foreground">
            Loading recent posts...
          </div>
        ) : recentTweets.length === 0 ? (
          <div className="py-8 text-center text-muted-foreground">
            No posts yet. Create your first post with AI assistance!
          </div>
        ) : (
          <div className="space-y-4">
            {recentTweets.map((tweet) => (
              <div key={tweet.id} className={`p-4 rounded-lg ${isSimulatedTweet(tweet.id) ? 'bg-primary/5 border-primary/20' : 'bg-white/5 border-white/10'} hover:bg-white/10 transition-colors border`}>
                <p className="text-sm mb-2">{tweet.text}</p>
                <div className="flex justify-between items-center mt-2">
                  <div className="text-xs text-muted-foreground flex items-center">
                    {formatDate(tweet.createdAt)}
                    {isSimulatedTweet(tweet.id) && (
                      <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                        <InfoIcon size={10} className="mr-1" />
                        Simulated
                      </span>
                    )}
                  </div>
                  <div className="flex space-x-4 text-xs text-muted-foreground">
                    <span className="flex items-center">
                      <MessageSquare size={12} className="mr-1" /> {tweet.replies}
                    </span>
                    <span className="flex items-center">
                      <Zap size={12} className="mr-1" /> {tweet.retweets}
                    </span>
                    <span className="flex items-center">
                      <LineChart size={12} className="mr-1" /> {tweet.likes}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default PostHistory;
