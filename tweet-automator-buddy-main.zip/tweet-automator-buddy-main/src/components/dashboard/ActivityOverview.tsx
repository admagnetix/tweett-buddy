
import React from 'react';
import { Zap, Twitter } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const ActivityOverview: React.FC = () => {
  return (
    <Card className="shadow-soft border border-white/10 bg-gradient-glass backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-lg font-medium">Activity Overview</CardTitle>
        <CardDescription>
          Recent activity from your AI agent
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
            <div className="flex items-center text-sm font-medium text-primary mb-1">
              <Zap size={14} className="mr-2" />
              Automated Engagement
            </div>
            <p className="text-sm text-muted-foreground">
              Your agent liked 8 posts and replied to 3 tweets in your target niche today.
            </p>
          </div>
          
          <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
            <div className="flex items-center text-sm font-medium text-primary mb-1">
              <Twitter size={14} className="mr-2" />
              Content Suggestion
            </div>
            <p className="text-sm text-muted-foreground">
              AI detected a trending topic in your niche: "The impact of generative AI on content creation"
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ActivityOverview;
