
import React from 'react';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const DemoAlert: React.FC = () => {
  return (
    <Alert className="mb-8 bg-gradient-glass backdrop-blur-sm border-yellow-500/50">
      <AlertCircle className="h-4 w-4 text-yellow-500" />
      <AlertTitle>Demo Application</AlertTitle>
      <AlertDescription>
        This is a demo application. Posts and engagements are simulated and not actually sent to Twitter.
        To create a full Twitter integration, you would need to build a backend with the Twitter API.
      </AlertDescription>
    </Alert>
  );
};

export default DemoAlert;
