
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Container from '@/components/layout/Container';
import TwitterStatus from './TwitterStatus';
import DemoAlert from './DemoAlert';
import ContentTabs from './ContentTabs';
import ActivityOverview from './ActivityOverview';
import QuickLinks from './QuickLinks';
import EngagementSettings from '@/components/engagement/EngagementSettings';
import { twitterService } from '@/services/twitter';
import type { Tweet } from '@/services/twitter';

const Dashboard: React.FC = () => {
  const [recentTweets, setRecentTweets] = useState<Tweet[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  
  useEffect(() => {
    // Check if connected to Twitter
    if (!twitterService.isConnected()) {
      navigate('/connect');
      return;
    }
    
    // Load recent tweets
    const loadTweets = async () => {
      try {
        const tweets = await twitterService.getRecentTweets();
        setRecentTweets(tweets);
      } catch (error) {
        console.error('Failed to load tweets:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadTweets();
  }, [navigate]);
  
  const handlePostCreated = async () => {
    // Reload tweets to show the new one
    setIsLoading(true);
    try {
      const tweets = await twitterService.getRecentTweets();
      setRecentTweets(tweets);
    } catch (error) {
      console.error('Failed to refresh tweets:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20 pb-16">
      <div className="h-16" /> {/* Spacer for header */}
      
      <Container className="mt-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Manage your Twitter automation and engagement
            </p>
          </div>
          <TwitterStatus />
        </div>
        
        <DemoAlert />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-8">
            <ContentTabs 
              recentTweets={recentTweets} 
              isLoading={isLoading} 
              onPostCreated={handlePostCreated} 
            />
            
            <ActivityOverview />
          </div>
          
          <div className="space-y-8">
            <EngagementSettings />
            <QuickLinks />
          </div>
        </div>
      </Container>
    </div>
  );
};

export default Dashboard;
