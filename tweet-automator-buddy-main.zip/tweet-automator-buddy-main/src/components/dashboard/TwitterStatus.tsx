
import React from 'react';
import { Twitter, Info } from 'lucide-react';
import { twitterService } from '@/services/twitter';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const TwitterStatus: React.FC = () => {
  return (
    <div className="flex items-center space-x-2 bg-twitter-blue/10 px-3 py-1.5 rounded-full">
      <Twitter size={16} className="text-twitter-blue" />
      <span className="text-sm font-medium text-twitter-blue">
        @{twitterService.getUsername()}
      </span>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger>
            <div className="flex items-center">
              <Info size={14} className="text-amber-500 ml-1" />
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-[200px]">
              This is running in simulation mode. A backend service is required for actual Twitter posting.
            </p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
};

export default TwitterStatus;
