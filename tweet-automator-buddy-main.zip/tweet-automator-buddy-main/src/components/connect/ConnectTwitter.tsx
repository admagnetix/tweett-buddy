
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Twitter, Lock, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { twitterService } from '@/services/twitter';

const ConnectTwitter: React.FC = () => {
  const [accessToken, setAccessToken] = useState('');
  const [accessSecret, setAccessSecret] = useState('');
  const [username, setUsername] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!accessToken || !accessSecret || !username) {
      toast.error('Please fill in all fields');
      return;
    }
    
    setIsLoading(true);
    
    try {
      // In a real app, you'd validate these tokens with the Twitter API
      // For this demo, we'll just save them
      twitterService.saveTokens({
        accessToken,
        accessSecret,
        username
      });
      
      toast.success('Successfully connected to Twitter!');
      navigate('/dashboard');
    } catch (error) {
      console.error('Failed to connect:', error);
      toast.error('Failed to connect to Twitter. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto py-12 px-4 animate-fade-up">
      <Card className="glass shadow-soft border border-white/20">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-4">
            <div className="w-12 h-12 rounded-full bg-twitter-blue/10 flex items-center justify-center">
              <Twitter className="h-6 w-6 text-twitter-blue" />
            </div>
          </div>
          <CardTitle className="text-xl font-semibold text-center">Connect to Twitter</CardTitle>
          <CardDescription className="text-center">
            Enter your Twitter API credentials to connect your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleConnect} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Twitter Username</Label>
              <Input
                id="username"
                placeholder="@yourusername"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-white/5 backdrop-blur-sm border-white/10 focus:border-white/30 transition-all"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="accessToken">Access Token</Label>
              <Input
                id="accessToken"
                type="password"
                placeholder="Enter your access token"
                value={accessToken}
                onChange={(e) => setAccessToken(e.target.value)}
                className="bg-white/5 backdrop-blur-sm border-white/10 focus:border-white/30 transition-all"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="accessSecret">Access Token Secret</Label>
              <Input
                id="accessSecret"
                type="password"
                placeholder="Enter your access token secret"
                value={accessSecret}
                onChange={(e) => setAccessSecret(e.target.value)}
                className="bg-white/5 backdrop-blur-sm border-white/10 focus:border-white/30 transition-all"
              />
            </div>
            
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Lock size={14} />
              <span>Your credentials are stored locally and never sent to our servers</span>
            </div>
          </form>
        </CardContent>
        <CardFooter>
          <Button 
            type="submit" 
            onClick={handleConnect}
            disabled={isLoading} 
            className="w-full bg-twitter-blue hover:bg-twitter-dark text-white transition-all"
          >
            {isLoading ? 'Connecting...' : 'Connect Account'}
          </Button>
        </CardFooter>
        <div className="p-4 bg-yellow-50 rounded-b-lg border-t border-yellow-100">
          <div className="flex space-x-2 text-sm text-amber-800">
            <AlertCircle size={16} />
            <div>
              <p className="font-medium">Important Note</p>
              <p className="mt-1">
                For a production app, you would implement OAuth to securely connect to Twitter.
                This demo uses direct token input for educational purposes only.
              </p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default ConnectTwitter;
