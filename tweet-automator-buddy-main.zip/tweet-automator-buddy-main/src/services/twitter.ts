
// Twitter API integration service

interface TwitterToken {
  accessToken: string;
  accessSecret: string;
  username: string;
}

export interface Tweet {
  id: string;
  text: string;
  createdAt: string;
  likes: number;
  retweets: number;
  replies: number;
}

interface PostHistory {
  text: string;
  timestamp: string;
  status: 'success' | 'error' | 'simulated';
  errorMessage?: string;
}

class TwitterService {
  private tokens: TwitterToken | null = null;
  private postHistory: PostHistory[] = [];
  
  constructor() {
    // Load tokens from localStorage if available
    const savedTokens = localStorage.getItem('twitter_tokens');
    const savedHistory = localStorage.getItem('twitter_post_history');
    
    if (savedTokens) {
      try {
        this.tokens = JSON.parse(savedTokens);
      } catch (error) {
        console.error('Failed to parse saved tokens:', error);
        localStorage.removeItem('twitter_tokens');
      }
    }
    
    if (savedHistory) {
      try {
        this.postHistory = JSON.parse(savedHistory);
      } catch (error) {
        console.error('Failed to parse saved post history:', error);
        localStorage.removeItem('twitter_post_history');
      }
    }
  }
  
  isConnected(): boolean {
    return !!this.tokens;
  }
  
  getUsername(): string | null {
    return this.tokens?.username || null;
  }
  
  saveTokens(tokens: TwitterToken): void {
    this.tokens = tokens;
    localStorage.setItem('twitter_tokens', JSON.stringify(tokens));
  }
  
  clearTokens(): void {
    this.tokens = null;
    localStorage.removeItem('twitter_tokens');
  }
  
  getPostHistory(): PostHistory[] {
    return [...this.postHistory];
  }
  
  async postTweet(text: string): Promise<boolean> {
    if (!this.isConnected()) {
      throw new Error('Not connected to Twitter');
    }
    
    console.log('Posting tweet:', text);
    
    try {
      // Use OAuth 1.0a for posting to Twitter API v2
      const result = await this.postToTwitterAPI(text);
      
      // Add to post history
      const newPost = {
        text,
        timestamp: new Date().toISOString(),
        status: 'success' as const,
      };
      
      this.postHistory = [newPost, ...this.postHistory];
      localStorage.setItem('twitter_post_history', JSON.stringify(this.postHistory));
      
      return true;
    } catch (error) {
      console.error('Error posting to Twitter:', error);
      
      // Add failed post to history
      const newPost = {
        text,
        timestamp: new Date().toISOString(),
        status: 'error' as const,
        errorMessage: error instanceof Error ? error.message : 'Unknown error'
      };
      
      this.postHistory = [newPost, ...this.postHistory];
      localStorage.setItem('twitter_post_history', JSON.stringify(this.postHistory));
      
      throw error;
    }
  }
  
  private async postToTwitterAPI(text: string): Promise<any> {
    if (!this.tokens) {
      throw new Error('Not connected to Twitter');
    }
    
    // This is where we'd normally use a Twitter API library or direct API calls
    // For security reasons, this should be handled by a backend service
    // Since we're in a frontend-only app, we'll use a proxy approach
    
    // Create a TwitterAPI proxy URL that you'd host separately
    // You would need to set up a simple backend service to handle Twitter API calls
    // This could be a serverless function on Vercel, Netlify, AWS Lambda, etc.
    const proxyUrl = 'https://your-twitter-proxy-api.vercel.app/api/tweet';
    
    const response = await fetch(proxyUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text,
        accessToken: this.tokens.accessToken,
        accessSecret: this.tokens.accessSecret,
        username: this.tokens.username
      }),
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to post tweet');
    }
    
    return await response.json();
  }
  
  async getRecentTweets(): Promise<Tweet[]> {
    if (!this.isConnected()) {
      throw new Error('Not connected to Twitter');
    }
    
    try {
      // This would be a real API call in a production app
      // For now, we'll return post history plus example data
      
      // First include history of real posts
      const realPosts = this.postHistory.map((post, index) => ({
        id: `post-${index}`,
        text: post.text,
        createdAt: post.timestamp,
        likes: Math.floor(Math.random() * 20),
        retweets: Math.floor(Math.random() * 10),
        replies: Math.floor(Math.random() * 5),
      }));
      
      // Then add example tweets
      const exampleTweets = [
        {
          id: '1',
          text: 'Just exploring the latest AI trends! #AI #MachineLearning',
          createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
          likes: 42,
          retweets: 7,
          replies: 3
        },
        {
          id: '2',
          text: 'The future of automation is here. What are your thoughts on AI-powered workflows?',
          createdAt: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
          likes: 24,
          retweets: 5,
          replies: 8
        }
      ];
      
      return [...realPosts, ...exampleTweets];
    } catch (error) {
      console.error('Error fetching tweets:', error);
      throw error;
    }
  }
  
  async engageWithTweet(tweetId: string, action: 'like' | 'retweet' | 'reply', replyText?: string): Promise<boolean> {
    if (!this.isConnected()) {
      throw new Error('Not connected to Twitter');
    }
    
    try {
      // This would be a real API call in a production app
      console.log(`Performing ${action} on tweet ${tweetId}`);
      
      // Implementation would be similar to postToTwitterAPI method
      // Different endpoint depending on the action (like, retweet, reply)
      
      return true;
    } catch (error) {
      console.error(`Error performing ${action}:`, error);
      throw error;
    }
  }
}

export const twitterService = new TwitterService();
