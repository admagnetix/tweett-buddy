
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, Twitter, Sparkles, Bot, LineChart, MessageSquare, Shield, PlusSquare } from 'lucide-react';
import Header from '@/components/layout/Header';
import Container from '@/components/layout/Container';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 md:pt-32 md:pb-24 relative overflow-hidden">
        <Container className="relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6 animate-fade-in">
              <Sparkles size={14} className="mr-2" />
              <span>AI-Powered Twitter Management</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6 animate-fade-up">
              Elevate Your Twitter Presence with AI
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground mb-8 animate-fade-up" style={{ animationDelay: '100ms' }}>
              Create engaging content, automate interactions, and grow your audience with our intelligent Twitter agent
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-up" style={{ animationDelay: '200ms' }}>
              <Button asChild size="lg" className="bg-twitter-blue hover:bg-twitter-dark text-white">
                <Link to="/connect">
                  <Twitter size={18} className="mr-2" />
                  Connect Your Account
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-primary/20 text-primary hover:bg-primary/10">
                <Link to="/dashboard">
                  Explore Dashboard
                  <ArrowRight size={18} className="ml-2" />
                </Link>
              </Button>
            </div>
          </div>
        </Container>
        
        {/* Decorative background elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
          <div className="absolute top-20 left-10 w-72 h-72 rounded-full bg-primary/5 blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 rounded-full bg-twitter-blue/5 blur-3xl"></div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-16 md:py-24 relative">
        <Container>
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold tracking-tight mb-4">Powerful Features</h2>
            <p className="text-lg text-muted-foreground">
              Everything you need to automate and enhance your Twitter presence
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="group p-6 rounded-xl bg-gradient-glass backdrop-blur-sm border border-white/10 hover:border-primary/20 hover:shadow-soft transition-all">
              <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Bot size={24} />
              </div>
              <h3 className="text-xl font-medium mb-2">AI Content Creation</h3>
              <p className="text-muted-foreground">
                Generate engaging tweets tailored to your brand voice and audience preferences.
              </p>
            </div>
            
            <div className="group p-6 rounded-xl bg-gradient-glass backdrop-blur-sm border border-white/10 hover:border-primary/20 hover:shadow-soft transition-all">
              <div className="w-12 h-12 rounded-full bg-twitter-blue/10 text-twitter-blue flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <MessageSquare size={24} />
              </div>
              <h3 className="text-xl font-medium mb-2">Smart Engagement</h3>
              <p className="text-muted-foreground">
                Automatically engage with relevant content and creators in your niche.
              </p>
            </div>
            
            <div className="group p-6 rounded-xl bg-gradient-glass backdrop-blur-sm border border-white/10 hover:border-primary/20 hover:shadow-soft transition-all">
              <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <LineChart size={24} />
              </div>
              <h3 className="text-xl font-medium mb-2">Performance Analytics</h3>
              <p className="text-muted-foreground">
                Track engagement metrics and optimize your strategy with data-driven insights.
              </p>
            </div>
            
            <div className="group p-6 rounded-xl bg-gradient-glass backdrop-blur-sm border border-white/10 hover:border-primary/20 hover:shadow-soft transition-all">
              <div className="w-12 h-12 rounded-full bg-twitter-blue/10 text-twitter-blue flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <PlusSquare size={24} />
              </div>
              <h3 className="text-xl font-medium mb-2">Content Scheduling</h3>
              <p className="text-muted-foreground">
                Plan and schedule your tweets for optimal posting times to maximize reach.
              </p>
            </div>
            
            <div className="group p-6 rounded-xl bg-gradient-glass backdrop-blur-sm border border-white/10 hover:border-primary/20 hover:shadow-soft transition-all">
              <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Sparkles size={24} />
              </div>
              <h3 className="text-xl font-medium mb-2">Trend Discovery</h3>
              <p className="text-muted-foreground">
                Identify trending topics in your niche to keep your content relevant and timely.
              </p>
            </div>
            
            <div className="group p-6 rounded-xl bg-gradient-glass backdrop-blur-sm border border-white/10 hover:border-primary/20 hover:shadow-soft transition-all">
              <div className="w-12 h-12 rounded-full bg-twitter-blue/10 text-twitter-blue flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Shield size={24} />
              </div>
              <h3 className="text-xl font-medium mb-2">Secure & Private</h3>
              <p className="text-muted-foreground">
                Your Twitter credentials are stored securely and never shared with third parties.
              </p>
            </div>
          </div>
        </Container>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 md:py-24">
        <Container>
          <div className="max-w-4xl mx-auto rounded-2xl overflow-hidden bg-gradient-glass backdrop-blur-md border border-white/10 shadow-soft">
            <div className="p-8 md:p-12 text-center">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Ready to transform your Twitter strategy?</h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Connect your Twitter account today and experience the power of AI-driven content creation and engagement.
              </p>
              <Button asChild size="lg" className="bg-twitter-blue hover:bg-twitter-dark text-white">
                <Link to="/connect">
                  <Twitter size={18} className="mr-2" />
                  Get Started Now
                </Link>
              </Button>
            </div>
          </div>
        </Container>
      </section>
      
      {/* Footer */}
      <footer className="py-12 border-t border-white/10">
        <Container>
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Twitter size={20} className="text-twitter-blue" />
              <span className="font-semibold">AI X Agent</span>
            </div>
            <div className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} AI X Agent. All rights reserved.
            </div>
          </div>
        </Container>
      </footer>
    </div>
  );
};

export default Index;
